package com.musdon.authenticationsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
